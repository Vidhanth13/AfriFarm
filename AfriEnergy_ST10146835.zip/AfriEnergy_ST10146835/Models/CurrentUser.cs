﻿namespace AfriEnergy_ST10146835.Models
{
    // Class for storing the currently logged-in user's information
    public class CurrentUser
    {
        public static string currentUser { get; set; } // Property to hold the username of the current user
    }
}
